Tips: 


Windows 7/8 need to download updates .NET Framework components.
Download link: https://www.microsoft.com/en-us/download/details.aspx?id=53344


Have a problem? Contact us: https://hato.zendesk.com/hc/en-us/requests/new 
